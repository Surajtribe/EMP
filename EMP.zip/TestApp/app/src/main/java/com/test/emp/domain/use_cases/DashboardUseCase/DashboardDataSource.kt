package com.test.emp.domain.use_cases.DashboardUseCase

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.test.emp.data.models.dashboardModel.Data
import com.test.emp.domain.repository.TestAppRepository

class DashboardDataSource(
    private val repo: TestAppRepository,
    page: Int,
    ) : PagingSource<Int, Data>() {

    override fun getRefreshKey(state: PagingState<Int, Data>): Int? {
        return state.anchorPosition?.let { position ->
            val page = state.closestPageToPosition(position)
            page?.prevKey?.minus(1) ?: page?.nextKey?.plus(1)
        }
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, Data> {

        return try {
            val page = params.key ?: 1
            val response = repo.getDashboard(
                pageNumber = page
            )
            LoadResult.Page(
                data = response.data,
                prevKey = null,
                nextKey = if (response.data.isNotEmpty()) page + 1 else null
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }
}