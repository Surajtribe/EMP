package com.test.emp.presentation.navigation

import android.annotation.SuppressLint
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.test.emp.presentation.Screens.dashboard.DashboardScreen
import com.mardom.presentation.screens.splash.SplashScreen

@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun SetupNavGraph(navController: NavHostController) {

    NavHost(
        navController = navController,
        startDestination = Screens.SplashScreen.route
    ) {
        composable(route = Screens.SplashScreen.route) {
            SplashScreen(navController = navController)
        }
        composable(route = Screens.DashboardScreen.route) {
            DashboardScreen(navController = navController)
        }
    }
}