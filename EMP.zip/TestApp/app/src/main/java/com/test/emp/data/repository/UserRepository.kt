package com.test.emp.data.repository

import com.google.firebase.database.FirebaseDatabase
import com.test.emp.data.models.dashboardModel.User
import kotlinx.coroutines.tasks.await
import com.google.firebase.firestore.FirebaseFirestore
import javax.inject.Inject

class UserRepository @Inject constructor() {

    private val db = FirebaseFirestore.getInstance()
    private val usersCollection = db.collection("users")
    private val userRef = FirebaseDatabase.getInstance().getReference("users")


    // 🔹 Save user to Firebase
    suspend fun saveUser(user: User): Boolean {
        return try {
            usersCollection.add(user).await() // Add user to Firestore
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // 🔹 Get users from Firebase
    suspend fun getUsers(): List<User> {
        return try {
            val snapshot = usersCollection.get().await()
            snapshot.documents.mapNotNull { it.toObject(User::class.java) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // 🔹 Delete user from Firebase
    suspend fun deleteUser(name: String, dob: String) {
        try {
            val snapshot = usersCollection
                .whereEqualTo("name", name)
                .whereEqualTo("dob", dob)
                .get()
                .await()

            for (document in snapshot) {
                usersCollection.document(document.id).delete().await()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun updateUser(oldName: String, updatedUser: User): Boolean {
        return try {
            val snapshot = usersCollection
                .whereEqualTo("name", oldName)
                .get()
                .await()
            if (snapshot.isEmpty) {
                return false
            }
            for (document in snapshot) {
                usersCollection.document(document.id).set(updatedUser)
                    .await()
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
