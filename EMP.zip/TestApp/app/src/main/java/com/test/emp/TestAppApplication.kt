package com.test.emp

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import dagger.hilt.android.HiltAndroidApp
import java.util.Locale

@HiltAndroidApp
class TestAppApplication : Application() {
}