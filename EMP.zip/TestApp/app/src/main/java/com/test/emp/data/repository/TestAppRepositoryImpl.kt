package com.test.emp.data.repository

import com.test.emp.data.api.TestAppApi
import com.test.emp.data.models.dashboardModel.DashboardModel
import com.test.emp.domain.repository.TestAppRepository
import javax.inject.Inject


class TestAppRepositoryImpl @Inject constructor(
    private val api: TestAppApi
) : TestAppRepository {

    override suspend fun getDashboard(pageNumber: Int): DashboardModel {
        return api.getDashboardData(pageNumber)
    }
}