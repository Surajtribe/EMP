package com.test.emp.di

import com.google.firebase.firestore.FirebaseFirestore
import com.test.emp.data.api.TestAppApi
import com.test.emp.data.repository.TestAppRepositoryImpl
import com.test.emp.domain.repository.TestAppRepository
import com.test.emp.util.Constants.BASE_URL
import com.google.gson.GsonBuilder
import com.test.emp.data.repository.UserRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton


@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    private val gson = GsonBuilder().setLenient().create()
    private val okHttpClient = OkHttpClient.Builder()
    val interceptor = HttpLoggingInterceptor()

    @Provides
    @Singleton
    fun provideDashboardRepository(
        api: TestAppApi): TestAppRepository {
        return TestAppRepositoryImpl(api)
    }

    @Singleton
    @Provides
    fun provideTestAppApi(): TestAppApi {
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
        okHttpClient.addInterceptor(interceptor)
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .client(okHttpClient.build())
            .build()
            .create(TestAppApi::class.java)
    }

    @Provides
    @Singleton
    fun provideFirestore(): FirebaseFirestore = FirebaseFirestore.getInstance()

    @Module
    @InstallIn(SingletonComponent::class)
    object AppModule {
        @Provides
        @Singleton
        fun provideUserRepository(): UserRepository {
            return UserRepository()
        }
    }

}