package com.test.emp.presentation.Screens.dashboard

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.test.emp.data.models.dashboardModel.Data
import com.test.emp.domain.use_cases.DashboardUseCase.DashboardUseCase
import com.test.emp.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val dashboardUseCase: DashboardUseCase,
    ) : ViewModel() {

    private val _dashboardState = mutableStateOf(DashboardState())
    var dashboardState: State<DashboardState> = _dashboardState

    private val _dataList = MutableStateFlow<List<Data>>(emptyList())
    val dataList = _dataList.asStateFlow()

    init {
        loadDashboardData(1)
    }

    fun loadDashboardData(page: Int) {
        viewModelScope.launch {
            dashboardUseCase.invoke(page = page).onEach {
                when(it){
                    is Resource.Success -> {
                        _dashboardState.value = DashboardState(dashboardModel = it.data)
                        _dataList.value = it.data!!.data
                    }
                    is Resource.Error -> {
                        _dashboardState.value = DashboardState(isLoading = false)
                    }
                    is Resource.Loading ->{
                        _dashboardState.value = DashboardState(isLoading = true)
                    }
                }
            }.launchIn(viewModelScope)
        }
    }

}