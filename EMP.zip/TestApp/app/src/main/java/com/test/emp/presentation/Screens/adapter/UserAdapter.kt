package com.test.emp.presentation.Screens.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.adysun.testapp.R
import com.test.emp.data.models.dashboardModel.User
import java.text.SimpleDateFormat
import java.util.Locale


/*class UserAdapter(
    private var userList: List<User>,
    private val onDelete: (User) -> Unit,
    private val onEdit: (User) -> Unit
) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    fun updateData(newList: List<User>) {
        userList = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = userList[position]
        holder.bind(user)

        holder.btnDelete.setOnClickListener {
            onDelete(user)
        }

        holder.editButton.setOnClickListener {
            onEdit(user)
        }
    }

    override fun getItemCount() = userList.size

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val btnDelete: ImageView = itemView.findViewById(R.id.deleteButton)
        val editButton: ImageView = itemView.findViewById(R.id.editButton)

        fun bind(user: User) {
            itemView.findViewById<TextView>(R.id.nameTextView).text = user.name
            itemView.findViewById<TextView>(R.id.desTextView).text = user.designation
            itemView.findViewById<TextView>(R.id.dobTextView).text = user.dob
        }
    }
}*/

class UserAdapter(
    private var userList: List<User>,
    private val onDelete: (User) -> Unit,
    private val onEdit: (User) -> Unit
) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    private var filteredList: List<User> = userList
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    fun updateData(newList: List<User>) {
        userList = newList
        filteredList = newList
        notifyDataSetChanged()
    }

    // 🔹 Filter users between two selected dates
    fun filterByDate(startDate: String, endDate: String) {
        try {
            val start = dateFormat.parse(startDate)
            val end = dateFormat.parse(endDate)

            filteredList = userList.filter { user ->
                val userDate = dateFormat.parse(user.dob)
                userDate != null && userDate in start..end
            }

            notifyDataSetChanged()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = filteredList[position]
        holder.bind(user)

        holder.btnDelete.setOnClickListener { onDelete(user) }
        holder.editButton.setOnClickListener { onEdit(user) }
    }

    override fun getItemCount() = filteredList.size

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val btnDelete: ImageView = itemView.findViewById(R.id.deleteButton)
        val editButton: ImageView = itemView.findViewById(R.id.editButton)

        fun bind(user: User) {
            itemView.findViewById<TextView>(R.id.nameTextView).text = user.name
            itemView.findViewById<TextView>(R.id.desTextView).text = user.designation
            itemView.findViewById<TextView>(R.id.dobTextView).text = user.dob
        }
    }
}

