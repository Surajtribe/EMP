package com.test.emp.presentation.Screens.activities

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adysun.testapp.R
import com.test.emp.data.models.dashboardModel.User
import com.test.emp.presentation.Screens.adapter.UserAdapter
import com.test.emp.presentation.viewmodel.UserViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@AndroidEntryPoint
class TestActivity : AppCompatActivity() {

    private val userViewModel: UserViewModel by viewModels()
    private lateinit var userAdapter: UserAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var edtSearch: EditText
    private lateinit var btnHistory: ImageButton
    private var userList: List<User> = emptyList()
    var startDate1 = ""
    private var endDate1 = ""

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test)

        val btnAdd = findViewById<ImageButton>(R.id.btnAdd)
        recyclerView = findViewById(R.id.recyclerView)
        edtSearch = findViewById(R.id.searchEditText)
        btnHistory = findViewById(R.id.btnHistory)
        recyclerView.layoutManager = LinearLayoutManager(this)
        userAdapter = UserAdapter(
            emptyList(),
            onDelete = { user ->
                showDeleteConfirmationDialog(user)
            },
            onEdit = { user ->
                val intent = Intent(this, UpdateActivity::class.java)
                intent.putExtra("USER_NAME", user.name)
                intent.putExtra("USER_DOB", user.dob)
                intent.putExtra("USER_DESIGNATION", user.designation)
                startActivity(intent)
            }
        )

        recyclerView.adapter = userAdapter

        btnAdd.setOnClickListener {
            val intent = Intent(this, UpdateActivity::class.java)
            startActivity(intent)
        }

        lifecycleScope.launch {
            userViewModel.users.collect { users ->
                userList = users
                userAdapter.updateData(users)
            }
        }

        userViewModel.fetchUsers()

        setupSearch()

        btnHistory.setOnClickListener {
            val datePicker = DateRangePickerDialog { startDate, endDate ->
                Toast.makeText(this, "Selected: $startDate to $endDate", Toast.LENGTH_LONG).show()
                this@TestActivity.startDate1 = startDate
                this@TestActivity.endDate1 = endDate

                Log.e("xxx", "onCreate: "+startDate1 )
                Log.e("xxx1", "onCreate: "+endDate1 )
                userAdapter.filterByDate(startDate1, endDate1)
            }
            datePicker.show(supportFragmentManager, "DateRangePicker")
        }
    }

    private fun setupSearch() {
        edtSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterUsers(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }
    private fun filterUsers(query: String) {
        val filteredList = if (query.isNotEmpty()) {
            userList.filter { it.name.contains(query, ignoreCase = true) }
        } else {
            userList
        }
        userAdapter.updateData(filteredList)
    }

    private fun showDeleteConfirmationDialog(user: User) {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_delete_confirmation)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        val btnYes = dialog.findViewById<Button>(R.id.btnYes)
        val btnNo = dialog.findViewById<Button>(R.id.btnNo)

        btnYes.setOnClickListener {
            userViewModel.deleteUser(user.name, user.dob)
            dialog.dismiss()
        }

        btnNo.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    override fun onResume() {
        super.onResume()
        userViewModel.fetchUsers()
    }

}

class DateRangePickerDialog(private val onDateRangeSelected: (String, String) -> Unit) : DialogFragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var calendarAdapter: CalendarAdapter
    private var startDate: Calendar? = null
    private var endDate: Calendar? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.dialog_date_range, container, false)

        recyclerView = view.findViewById(R.id.recyclerViewCalendar)
        val btnApply = view.findViewById<Button>(R.id.btnApply)

        // Setup RecyclerView
        calendarAdapter = CalendarAdapter(::onDateSelected)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = calendarAdapter

        // Apply Button Click
        btnApply.setOnClickListener {
            if (startDate != null && endDate != null) {
                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                onDateRangeSelected(sdf.format(startDate!!.time), sdf.format(endDate!!.time))
                dismiss() // Close dialog
            } else {
                Toast.makeText(requireContext(), "Please select a date range", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }

    override fun onResume() {
        super.onResume()
        val window = dialog?.window
        window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.9).toInt(),
            (resources.displayMetrics.heightPixels * 0.6).toInt() 
        )
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun onDateSelected(selectedDate: Calendar) {
        if (startDate == null || (startDate != null && endDate != null)) {
            startDate = selectedDate
            endDate = null
        } else {
            if (selectedDate.before(startDate)) {
                endDate = startDate
                startDate = selectedDate
            } else {
                endDate = selectedDate
            }
        }
        calendarAdapter.updateSelectedDates(startDate, endDate)
    }
}


class CalendarAdapter(private val onDateClick: (Calendar) -> Unit) : RecyclerView.Adapter<CalendarAdapter.MonthViewHolder>() {

    private val monthsList = mutableListOf<Calendar>()
    private var startDate: Calendar? = null
    private var endDate: Calendar? = null

    init {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_MONTH, 1)

        for (i in 0..11) { // Load 6 months initially
            val newMonth = calendar.clone() as Calendar
            monthsList.add(newMonth)
            calendar.add(Calendar.MONTH, 1)
        }
    }

    fun updateSelectedDates(start: Calendar?, end: Calendar?) {
        this.startDate = start
        this.endDate = end
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MonthViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_month, parent, false)
        return MonthViewHolder(view)
    }

    override fun onBindViewHolder(holder: MonthViewHolder, position: Int) {
        holder.bind(monthsList[position])
    }

    override fun getItemCount() = monthsList.size

    inner class MonthViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val monthTitle: TextView = itemView.findViewById(R.id.txtMonth)
        private val gridLayout: GridLayout = itemView.findViewById(R.id.gridCalendar)

        fun bind(month: Calendar) {
            val sdf = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
            monthTitle.text = sdf.format(month.time)

            gridLayout.removeAllViews()
            val calendar = month.clone() as Calendar
            val daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH)

            for (day in 1..daysInMonth) {
                val textView = TextView(itemView.context).apply {
                    text = day.toString()
                    textSize = 16f
                    gravity = Gravity.CENTER
                    setPadding(12, 12, 12, 12)

                    val date = calendar.clone() as Calendar
                    date.set(Calendar.DAY_OF_MONTH, day)

                    if (isDateSelected(date)) {
                        setBackgroundResource(R.drawable.selected_start_date)
                        setTextColor(Color.WHITE)
                    } else {
                        setBackgroundResource(R.drawable.default_day_background)
                        setTextColor(Color.LTGRAY)
                    }

                    setOnClickListener { onDateClick(date) }
                }

                val layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = ViewGroup.LayoutParams.WRAP_CONTENT
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                }

                gridLayout.addView(textView, layoutParams)
            }
        }

        private fun isDateSelected(date: Calendar): Boolean {
            return startDate?.let { s ->
                endDate?.let { e ->
                    (date == s || date == e || (date.after(s) && date.before(e)))
                } ?: (date == s)
            } ?: false
        }
    }
}

