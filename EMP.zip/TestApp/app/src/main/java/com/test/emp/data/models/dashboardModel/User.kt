package com.test.emp.data.models.dashboardModel

data class User(
    val name: String = "",
    val designation: String = "",
    val dob: String = ""
)