package com.test.emp.presentation.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.test.emp.data.models.dashboardModel.User
import com.test.emp.data.repository.UserRepository
import com.test.emp.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class UserViewModel @Inject constructor(
    private val repository: UserRepository
) : ViewModel() {

    private val _users = MutableStateFlow<List<User>>(emptyList())
    val users: StateFlow<List<User>> = _users

    private val _saveUserState = MutableLiveData<Resource<String>>()
    val saveUserState: LiveData<Resource<String>> = _saveUserState

    fun fetchUsers() {
        viewModelScope.launch {
            _users.value = repository.getUsers()
        }
    }

    fun deleteUser(name: String, dob: String) {
        viewModelScope.launch {
            repository.deleteUser(name, dob)
            fetchUsers()
        }
    }

    fun saveUser(user: User) {
        viewModelScope.launch {
            _saveUserState.value = Resource.Loading()
            try {
                repository.saveUser(user)
                fetchUsers()
                _saveUserState.value = Resource.Success("User saved successfully!")
            } catch (e: Exception) {
                _saveUserState.value = Resource.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun updateUser(oldName: String, updatedUser: User) {
        viewModelScope.launch {
            _saveUserState.value = Resource.Loading()
            try {
                val success = repository.updateUser(oldName, updatedUser)
                if (success) fetchUsers()
                _saveUserState.value = Resource.Success("User Update successfully!")
            } catch (e: Exception) {
                _saveUserState.value = Resource.Error(e.message ?: "Unknown error")
            }
        }
    }
}

