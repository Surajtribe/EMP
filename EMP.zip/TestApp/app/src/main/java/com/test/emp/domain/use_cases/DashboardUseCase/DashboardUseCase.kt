package com.test.emp.domain.use_cases.DashboardUseCase

import com.test.emp.data.models.dashboardModel.DashboardModel
import com.test.emp.domain.repository.TestAppRepository
import com.test.emp.util.Resource
import com.test.emp.util.Resource.Error
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject

class DashboardUseCase  @Inject constructor(
    private val repository: TestAppRepository
) {
    operator fun invoke(
        page: Int
    ): Flow<Resource<DashboardModel>> =
        flow {
            try {
                emit(Resource.Loading())
                val response = repository.getDashboard(page)
                emit(Resource.Success(response))

            } catch (e: HttpException) {
                emit(
                    Error(
                        e.localizedMessage ?: "An unexpected error occured"
                    )
                )
            } catch (e: IOException) {
                emit(
                    Error(
                        e.localizedMessage
                            ?: "Couldn't reach server. Check your internet connection."
                    )
                )
            }
        }
}