package com.test.emp.util

object Constants {

    const val BASE_URL = "https://reqres.in/api/"
}