package com.test.emp.presentation.Screens.dashboard

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.cachedIn
import com.test.emp.domain.repository.TestAppRepository
import com.test.emp.domain.use_cases.DashboardUseCase.DashboardDataSource
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class DashboardPaginationViewModel @Inject constructor(
    private val repository: TestAppRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val page : Int? = 1

    val dashboardData = Pager(
        PagingConfig(pageSize = 10)
    ) {
        DashboardDataSource(repository, page = page!!)
    }.flow.cachedIn(viewModelScope)
}
