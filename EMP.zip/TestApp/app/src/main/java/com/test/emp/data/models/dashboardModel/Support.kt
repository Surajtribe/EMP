package com.test.emp.data.models.dashboardModel

data class Support(
    val text: String,
    val url: String
)