package com.test.emp.presentation.Screens.activities

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.navigation.compose.rememberNavController
import com.test.emp.presentation.navigation.SetupNavGraph
import com.test.emp.presentation.ui.theme.TestAppTheme
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TestAppTheme {
                val systemUiController = rememberSystemUiController()
                SideEffect {
                    systemUiController.setStatusBarColor(
                        darkIcons = false,
                        color = Color.Black
                    )
                }
                val navController = rememberNavController()
                SetupNavGraph(navController = navController)
                val permission = Manifest.permission.POST_NOTIFICATIONS
                requestNotificationPermission.launch(permission)
            }
        }
    }

    private fun showPermissionRationaleDialog(mainActivity: MainActivity) {

        // Checking if permission is not granted
        if (ContextCompat.checkSelfPermission(
                mainActivity,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_DENIED
        ) {
            ActivityCompat.requestPermissions(
                mainActivity,
                arrayOf<String>(Manifest.permission.POST_NOTIFICATIONS),
                80
            )
        }

    }

    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted->
            if (isGranted) // make your action here
            else {
                showPermissionRationaleDialog(this)
            }
        }
}




