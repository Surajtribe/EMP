package com.test.emp.presentation.Screens.dashboard

import com.test.emp.data.models.dashboardModel.DashboardModel


data class DashboardState(
    val dashboardModel: DashboardModel? = null,
    val isLoading: Boolean = false,
    var isSuccessful: Boolean = false,
)