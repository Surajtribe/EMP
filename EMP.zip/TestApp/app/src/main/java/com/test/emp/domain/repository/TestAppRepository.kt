package com.test.emp.domain.repository

import com.test.emp.data.models.dashboardModel.DashboardModel

interface TestAppRepository {

    suspend fun getDashboard(pageNumber: Int): DashboardModel

}