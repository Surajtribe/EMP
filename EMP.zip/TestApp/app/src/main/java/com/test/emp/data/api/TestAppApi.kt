package com.test.emp.data.api

import com.test.emp.data.models.dashboardModel.DashboardModel
import retrofit2.http.GET
import retrofit2.http.Query


interface TestAppApi {

    @GET("users")
    suspend fun getDashboardData(
        @Query("page") page: Int,
    ): DashboardModel

}