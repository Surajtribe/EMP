package com.test.emp.presentation.Screens.activities

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.adysun.testapp.R
import com.test.emp.data.models.dashboardModel.User
import com.test.emp.presentation.viewmodel.UserViewModel
import com.test.emp.util.Resource
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class UpdateActivity : AppCompatActivity() {

    private val userViewModel: UserViewModel by viewModels()
    private lateinit var dobEditText: TextView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)

        val ll_dob = findViewById<LinearLayout>(R.id.ll_dob)
        val back = findViewById<ImageView>(R.id.back)
        val nameEditText = findViewById<EditText>(R.id.edt_name)
        dobEditText = findViewById(R.id.edt_dob)
        val desEditText = findViewById<EditText>(R.id.edt_designation)
        val saveButton = findViewById<Button>(R.id.btn_submit)

        val userName = intent.getStringExtra("USER_NAME")
        val userDob = intent.getStringExtra("USER_DOB")
        val userDes = intent.getStringExtra("USER_DESIGNATION")

        if (userName != null && userDob != null && userDes != null) {
            nameEditText.setText(userName)
            dobEditText.text = userDob
            desEditText.setText(userDes)
            saveButton.setOnClickListener {
                val name = nameEditText.text.toString()
                val dob = dobEditText.text.toString()
                val des = desEditText.text.toString()
                if (name.isNotEmpty() && dob.isNotEmpty() && des.isNotEmpty()) {
                    val updatedUser = User(name, des, dob)
                    userViewModel.updateUser( userName, updatedUser)
                } else {
                    Toast.makeText(this, "Please enter all details", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            saveButton.setOnClickListener {
                val name = nameEditText.text.toString()
                val dob = dobEditText.text.toString()
                val des = desEditText.text.toString()
                if (name.isNotEmpty() && dob.isNotEmpty() && des.isNotEmpty()) {
                    userViewModel.saveUser(User(name, des, dob))
                } else {
                    Toast.makeText(this, "Please enter all details", Toast.LENGTH_SHORT).show()
                }
            }
        }

        userViewModel.saveUserState.observe(this) { result ->
            when (result) {
                is Resource.Success -> {
                    Toast.makeText(this, result.data, Toast.LENGTH_SHORT).show()
                }
                is Resource.Error -> {
                    Toast.makeText(this, "Error: ${result.message}", Toast.LENGTH_SHORT).show()
                }
                is Resource.Loading -> {
                    Toast.makeText(this, "Saving...", Toast.LENGTH_SHORT).show()
                }
            }
        }

        back.setOnClickListener {
            onBackPressed()
        }

        ll_dob.setOnClickListener {
            showDatePickerDialog()
        }
    }

    private fun showDatePickerDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_date_picker)
        dialog.getWindow()?.setBackgroundDrawableResource(android.R.color.transparent);
        val calendarView = dialog.findViewById<CalendarView>(R.id.calendarView)
        val btnSubmit = dialog.findViewById<Button>(R.id.btnSubmit)

        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            val selectedDate = String.format("%02d/%02d/%04d", dayOfMonth, month + 1, year)
            btnSubmit.setOnClickListener {
                dobEditText.text = selectedDate
                dialog.dismiss()
            }
        }
        dialog.show()
    }
}