package com.test.emp.presentation.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

//MardomColorCodes
val MardomGreen = Color(0xFFa7dc01)
val MardomGray = Color(0xFF808080)
val MardomBlue = Color(0xFF07255B) //07255B
val MardomLightBlue = Color(0xFFE0EAFF)
val MardomMediumBlue = Color(0xFF074EE8)
val MardomDarkGray = Color(0xFF767676)
val MardomRed = Color(0xFFFC6B6B)
val MardomTextBlue = Color(0xFF6DA9FF)
val MardomFiltertheme = Color(0xFFEDEDF4)
val MardomDateCardColor = Color(0xFFDBE8FF)
val MardomTextGray = Color(0xFF828282)
val MardomWhite = Color(0xFFFFFFFF)
val MardomDividerBlue = Color(0xFF1E396A)//
val MardomProfileGray = Color(0xFFEDEDF4)
val MardomLightGray = Color(0xFFD8D8D8)
val MardomTitleBlue = Color(0xFF092E6E)
val MardomOceanBlue = Color(0xFF2096DB)
val MardomHintGray = Color(0xFFA4ACB2)
val MardomExtraDarkGray = Color(0xFF44444A)
val MardomMediumGray = Color(0xFF5D6362)
val MardomFaintGray = Color(0xFFA9ACBD)
val MardomChipGray = Color(0xFF757575)
val MardomResultGray = Color(0xFF74788D)
val Mardom80Gray = Color(0xFF808080)
val MardomD9Gray = Color(0xFFD9D9D9)
val MardomDarkBlue = Color(0xFF002E6D)
val MardomBackgroundBlue = Color(0xFFEFF0F5)
val MardomButtonBlue = Color(0xFF007bff)
val MardomTotalGray = Color(0xFFC7CAD7)

val mardom_blue = Color(0xFF07255B)
